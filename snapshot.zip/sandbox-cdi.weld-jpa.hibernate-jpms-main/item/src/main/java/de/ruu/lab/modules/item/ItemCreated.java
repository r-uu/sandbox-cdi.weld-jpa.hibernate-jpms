package de.ruu.lab.modules.item;

public interface ItemCreated
{
	Item item();
}
package de.ruu.lab.modules.shop.ui.fx.item;

import de.ruu.lib.fx.comp.FXCViewService;

public interface ItemService extends FXCViewService { }
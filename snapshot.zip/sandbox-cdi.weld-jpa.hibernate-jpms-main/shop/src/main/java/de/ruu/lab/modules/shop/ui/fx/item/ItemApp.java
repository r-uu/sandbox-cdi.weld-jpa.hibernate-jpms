package de.ruu.lab.modules.shop.ui.fx.item;

import de.ruu.lib.fx.comp.FXCApp;

class ItemApp extends FXCApp
{

}
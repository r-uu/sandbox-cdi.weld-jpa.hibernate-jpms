package de.ruu.lab.modules.shop.ui.fx.item.edit;

import de.ruu.lib.fx.comp.FXCViewService;

public interface EditService extends FXCViewService
{
	String name();
	String price();
}
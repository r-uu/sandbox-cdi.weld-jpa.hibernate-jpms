package de.ruu.lab.modules.shop.ui.fx.item;

import de.ruu.lib.fx.comp.DefaultFXCView;

public class Item extends DefaultFXCView
{

}
package de.ruu.lab.modules.shop.ui.fx.inventory;

import de.ruu.lib.fx.comp.FXCViewService;

public interface InventoryService extends FXCViewService { }
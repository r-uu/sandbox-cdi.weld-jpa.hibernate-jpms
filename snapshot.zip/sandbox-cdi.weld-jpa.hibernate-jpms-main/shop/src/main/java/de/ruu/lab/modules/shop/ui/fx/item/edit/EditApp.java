package de.ruu.lab.modules.shop.ui.fx.item.edit;

import de.ruu.lib.fx.comp.FXCApp;

public class EditApp extends FXCApp
{ }
package de.ruu.lab.modules.shop.ui.fx;

import de.ruu.lib.fx.comp.FXCApp;

public class ShopApp extends FXCApp
{
	@Override protected String getStageTitle() { return "shop"; }
}
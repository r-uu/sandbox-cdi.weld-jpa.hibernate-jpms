create database modules;
create schema item;
create schema inventory;
create schema order;
create schema catalog;